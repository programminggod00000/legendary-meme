# replit.md

## Overview

A minimalist, playful single-page web application built with React and Express. The app displays a cute animated GIF with "yay" text and an interactive clickable box that reveals a YouTube link when clicked. The design follows contemporary minimal portfolio aesthetics with clean typography and smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: shadcn/ui component library (New York style) built on Radix UI primitives
- **State Management**: TanStack React Query for server state
- **Build Tool**: Vite with hot module replacement

The frontend lives in `/client/src/` with:
- `pages/` - Route components (home, not-found)
- `components/ui/` - Reusable shadcn/ui components
- `hooks/` - Custom React hooks
- `lib/` - Utilities including API client and query configuration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **HTTP Server**: Node.js native http module wrapping Express
- **Development**: tsx for TypeScript execution, Vite dev server for HMR
- **Production Build**: esbuild for server bundling, Vite for client bundling

The backend lives in `/server/` with:
- `index.ts` - Server entry point and middleware setup
- `routes.ts` - API route registration (currently minimal)
- `storage.ts` - In-memory storage implementation with interface for future database
- `vite.ts` - Vite dev server integration
- `static.ts` - Static file serving for production

### Data Layer
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: Defined in `/shared/schema.ts` using Drizzle's pgTable
- **Validation**: Zod schemas generated from Drizzle schemas via drizzle-zod
- **Current Storage**: In-memory Map-based storage (MemStorage class)

The schema currently defines a users table with id, username, and password fields. The storage interface (`IStorage`) abstracts data operations, allowing easy swap from memory to database.

### Design System
- Typography: Inter font family with specific sizing (3rem desktop, 2rem mobile for headings)
- Spacing: Tailwind spacing units (4, 6, 8, 12, 16)
- Colors: CSS custom properties with light/dark mode support
- Components: Rounded corners, subtle shadows, smooth transitions (300ms ease)

## External Dependencies

### Core Services
- **PostgreSQL**: Database (configured via DATABASE_URL environment variable, Drizzle ready)
- **Google Fonts**: Inter font family loaded via CDN

### Key npm Packages
- **UI**: @radix-ui/* primitives, class-variance-authority, clsx, tailwind-merge
- **Data**: drizzle-orm, drizzle-zod, @tanstack/react-query
- **Server**: express, connect-pg-simple (session store ready)
- **Utilities**: zod, date-fns, nanoid

### Build & Development
- **Vite plugins**: @vitejs/plugin-react, @replit/vite-plugin-runtime-error-modal
- **TypeScript**: Strict mode enabled, path aliases configured (@/, @shared/, @assets/)