import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [boxClicked, setBoxClicked] = useState(false);
  const [showLink, setShowLink] = useState(false);

  const handleBoxClick = () => {
    setBoxClicked(true);
    setTimeout(() => {
      setShowLink(true);
    }, 300);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8 md:p-12 bg-background">
      <div className="flex flex-col items-center max-w-md w-full">
        <img
          src="https://i.pinimg.com/originals/e2/c3/51/e2c351ec8615647084ee85687b8c9132.gif"
          alt="Cute animated gif"
          className="w-[280px] md:w-[320px] rounded-xl shadow-lg"
          data-testid="img-main-gif"
        />
        
        <p 
          className="mt-8 text-[2rem] md:text-[3rem] font-medium tracking-tight text-pink-400"
          style={{ fontFamily: 'Inter, sans-serif', letterSpacing: '-0.02em' }}
          data-testid="text-yay"
        >
          yay (｡◕‿‿◕｡)
        </p>
        
        <div className="mt-8 relative flex flex-col items-center min-h-[52px]">
          <Button
            onClick={handleBoxClick}
            variant="outline"
            className={`px-8 py-4 text-lg font-medium text-pink-400 transition-opacity duration-300 ease-out ${
              boxClicked ? 'opacity-0 pointer-events-none absolute' : 'opacity-100'
            }`}
            style={{ fontFamily: 'Inter, sans-serif' }}
            data-testid="button-click-me"
            aria-label="Click to reveal link"
          >
            click me!
          </Button>
          
          {showLink && (
            <a
              href="https://www.youtube.com/watch?v=iWx6NXdy2NQ"
              target="_blank"
              rel="noopener noreferrer"
              className="text-base text-pink-400 underline underline-offset-4 transition-all duration-300 ease-out hover:opacity-70 animate-fade-in"
              style={{ fontFamily: 'Inter, sans-serif' }}
              data-testid="link-youtube"
              aria-label="YouTube video link"
            >
              https://www.youtube.com/watch?v=iWx6NXdy2NQ
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
