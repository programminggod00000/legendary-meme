# Design Guidelines: Minimalist Interactive Page

## Design Approach
**Minimalist, Playful Aesthetic** - Drawing inspiration from contemporary minimal portfolios and playful web experiences (like Poolsuite, Stripe's simplicity, or Bruno Simon's clean layouts). This single-screen experience prioritizes whitespace, centered composition, and delightful micro-interactions.

## Core Design Elements

### A. Typography
- **Primary Font**: Inter or Manrope (Google Fonts) - modern, geometric sans-serif
- **"yay" Text**: 
  - Font size: 3rem (desktop), 2rem (mobile)
  - Font weight: 500 (medium)
  - Letter spacing: slight (-0.02em for refined feel)
  - Lowercase styling for friendly, approachable tone

### B. Layout System
- **Spacing Units**: Tailwind units of 4, 6, 8, 12, 16 for consistent rhythm
- **Vertical Centering**: Full viewport height centering for all content
- **Container**: max-w-md (448px) for content wrapper
- **Spacing Between Elements**:
  - GIF to "yay" text: mb-6 (1.5rem)
  - "yay" to clickable box: mt-12 (3rem)

### C. Component Specifications

**1. GIF Display**
- Rounded corners: rounded-xl (0.75rem)
- Subtle shadow: shadow-lg for depth
- Max width: 320px on desktop, 280px on mobile
- Maintain aspect ratio

**2. "yay" Text**
- Center aligned
- Subtle opacity on initial load, full opacity after fade-in
- No background, pure text element

**3. Clickable Box**
- Padding: px-8 py-4
- Border: 2px solid with rounded-lg
- Cursor: pointer on hover
- Text: "Click me!" or playful emoji (✨ or 🎁)
- Font size: 1.125rem (18px)
- Transition: smooth fade-out on click (300ms ease)

**4. YouTube Link (Revealed)**
- Appears with fade-in after box disappears
- Underlined link styling
- Font size: 1rem (16px)
- Hover state: slight opacity change

### D. Interactions & Animations
- **Page Load**: Gentle fade-in for all elements (stagger: GIF → text → box)
- **Box Click**: Smooth opacity transition to 0, then display: none
- **Link Reveal**: Fade-in from opacity 0 to 1 (300ms)
- **Link Hover**: Subtle scale (1.02) and opacity change

## Visual Specifications

### Spacing & Rhythm
- Page padding: p-8 (mobile), p-12 (desktop)
- Vertical spacing maintains 1.5× relationship between elements
- All elements horizontally centered via flexbox

### Responsive Behavior
- Mobile (< 768px): Smaller GIF (280px), reduced font sizes, tighter spacing
- Desktop (≥ 768px): Full sizing as specified
- Maintains vertical centering across all viewports

## Content Structure
Single centered column containing:
1. GIF (top)
2. "yay" text (middle)
3. Clickable box / YouTube link (bottom)

All elements stack vertically with generous whitespace between them.

## Images
**Hero/Main Image**: The provided GIF serves as the primary visual element - no additional images needed. The GIF should be treated as the focal point with prominent placement and appropriate sizing.

## Accessibility
- Clickable box has clear interactive affordance
- Link includes proper aria-labels
- Keyboard navigation supported (Enter key triggers box click)
- Focus states visible on interactive elements

This design creates a playful, minimal single-page experience that's immediately understandable and delightful to interact with.